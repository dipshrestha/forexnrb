// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * Global variable containing the query we'd like to pass to Flickr. In this
 * case, kittens!
 *
 * @type {string}
 */
var QUERY = 'kittens';
var exURl = "http://rate-exchange.appspot.com/currency?from=USD&to=EUR";
var d = new Date();
var month = d.getMonth();
var day = d.getDate();
var day1 = day + 1;
var year = d.getFullYear();


var kittenGenerator = {
    /**
     * Flickr URL that will give us lots and lots of whatever we're looking for.
     *
     * See http://www.flickr.com/services/api/flickr.photos.search.html for
     * details about the construction of this URL.
     *
     * @type {string}
     * @private
     */
    //getExchangeRateUrl: 'http://rate-exchange.appspot.com/currency?from=USD&to=NPR',
    getExchangeRateUrl: 'http://www.nrb.org.np/exportForexXML.php?YY=' + year + '&MM=' + month + '&DD=' + day + '&YY1=' + year + '&MM1=' + month + '&DD1=' + day1 + '',
    /**
     * Sends an XHR GET request to grab photos of lots and lots of kittens. The
     * XHR's 'onload' event is hooks up to the 'showPhotos_' method.
     *
     * @public
     */
    LoadExchangeRate: function () {
        var jsonArr = [];
        var req = new XMLHttpRequest();
        req.open("GET", this.getExchangeRateUrl, true);
        req.onreadystatechange = function () {
            if (req.readyState == 4) {
                var xmlDoc = req.responseXML;
                // var json = $.xml2json(xmlDoc);
                //alert(json.CurrencyConversion[0]);
                //alert(json.CurrencyConversion.CurrencyConversionResponse[0].BaseCurrency.text);//["CurrencyConversionResponse"]);
                var x = xmlDoc.getElementsByTagName("CurrencyConversionResponse");
                var innerval = "";

                for (i = 0; i < x.length; i++) {

                    document.getElementById('curDate').innerHTML = d;
                    var from = x[i].getElementsByTagName("BaseCurrency")[0].childNodes[0].nodeValue;
                    var to = x[i].getElementsByTagName("TargetCurrency")[0].childNodes[0].nodeValue;
                    var rate = x[i].getElementsByTagName("ConversionRate")[0].childNodes[0].nodeValue;
                    innerval = innerval + "<div>" + from + " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rate + "</div>";

                 

                }

                

                document.getElementById("exchangeRate").innerHTML = innerval;
                //--document.getElementById("fromValue").innerHTML = resp["from"];
                //document.getElementById("toValue").innerHTML = resp["to"];
                //document.getElementById("rateValue").innerHTML = resp["rate"];
            }
        }
        jsonArr.push({
            label: "JAN",
            y: 10
        });
        jsonArr.push({
            label: "FeB",
            y: 12
        });
        jsonArr.push({
            label: "Mar",
            y: 9
        });
      //  dataPointsTemp.push({ label: data[i].label, y: data[i].y });

       // alert(jsonArr);
       // var obj = jsonArr.evalJSON(true);
        // req.onload = this.showPhotos_.bind(this);
      //  alert(jsonArr);
        req.send(null);
        this.generateChart(jsonArr);



    },

    generateChart: function (chartData) {
        //alert('abc');
        var chart = new CanvasJS.Chart("chartContainer", {
            theme: "theme2",//theme1
            title: {
                text: "Basic Column Chart - CanvasJS"
            },
            animationEnabled: false,   // change to true
            data: [
            {
                // Change type to "bar", "splineArea", "area", "spline", "pie",etc.
                type: "column",
                datapoints: chartData
                //dataPoints: [
                //    { label: "Jan", y: 10 },
                //    { label: "Feb", y: 15 },
                //    { label: "March", y: 25 },
                //    { label: "April", y: 30 },
                //    { label: "May", y: 28 }
                //]
            }
            ]
        });
        chart.render();
    }

    /**
     * Handle the 'onload' event of our kitten XHR request, generated in
     * 'requestKittens', by generating 'img' elements, and stuffing them into
     * the document for display.
     *
     * @param {ProgressEvent} e The XHR ProgressEvent.
     * @private
     */
    /*
  showPhotos_: function (e) {
    var kittens = e.target.responseXML.querySelectorAll('photo');
    for (var i = 0; i < kittens.length; i++) {
      var img = document.createElement('img');
      img.src = this.constructKittenURL_(kittens[i]);
      img.setAttribute('alt', kittens[i].getAttribute('title'));
      document.body.appendChild(img);
    }
  },
  */

    /**
     * Given a photo, construct a URL using the method outlined at
     * http://www.flickr.com/services/api/misc.urlKittenl
     *
     * @param {DOMElement} A kitten.
     * @return {string} The kitten's URL.
     * @private
     */
    /*
  constructKittenURL_: function (photo) {
    return "http://farm" + photo.getAttribute("farm") +
        ".static.flickr.com/" + photo.getAttribute("server") +
        "/" + photo.getAttribute("id") +
        "_" + photo.getAttribute("secret") +
        "_s.jpg";
  }*/
};

// Run our kitten generation script as soon as the document's DOM is ready.
document.addEventListener('DOMContentLoaded', function () {
    kittenGenerator.LoadExchangeRate();
});
